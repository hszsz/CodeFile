package cn.com.scitc.webapp11701;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Webapp11701ApplicationTests {

    @Test
    public void contextLoads() {
    }

}
