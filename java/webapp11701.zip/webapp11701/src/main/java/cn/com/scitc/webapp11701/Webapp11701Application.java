package cn.com.scitc.webapp11701;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Webapp11701Application {

    public static void main(String[] args) {
        SpringApplication.run(Webapp11701Application.class, args);
    }

}
