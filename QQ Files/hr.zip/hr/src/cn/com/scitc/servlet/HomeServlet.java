package cn.com.scitc.servlet;

import cn.com.scitc.dao.EmployeeDao;
import cn.com.scitc.model.Employee;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "HomeServlet")
public class HomeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Employee> list = new EmployeeDao().findAll();
        request.setAttribute("list", list);

        request.getRequestDispatcher("/WEB-INF/home.jsp").forward(request, response);
    }
}
