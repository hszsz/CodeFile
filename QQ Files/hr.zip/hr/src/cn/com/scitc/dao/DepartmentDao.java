package cn.com.scitc.dao;

public class DepartmentDao {

}
