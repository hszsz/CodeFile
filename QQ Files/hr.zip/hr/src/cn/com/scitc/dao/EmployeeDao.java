package cn.com.scitc.dao;

import cn.com.scitc.model.Employee;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDao {

    public List<Employee> findAll() {
        String sql = "select * from employee";

        ResultSet resultSet = SqlHelper.executeQuery(sql, null);

        List<Employee> list = new ArrayList<>();
        try {
            while (resultSet.next()) {
                Employee model = new Employee();
                model.setId(resultSet.getInt("id"));
                model.setName(resultSet.getString("name"));
                model.setDepartmentId(resultSet.getInt("departmentId"));
                model.setAddress(resultSet.getString("address"));
                model.setMobile(resultSet.getString("mobile"));
                model.setBirthday(resultSet.getDate("birthday"));

                list.add(model);
            }
            return  list;
        }
        catch (Exception er) {
            er.printStackTrace();
            return null;
        }
    }
}
