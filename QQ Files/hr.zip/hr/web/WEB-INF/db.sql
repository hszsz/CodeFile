create database hr1 charset utf8;

create user 'hr1'@'localhost' identified by 'hr1';

grant all on hr1.* to 'hr1'@'localhost';

create table department (
    id int not null auto_increment primary key,     #主键
    name varchar(100),                              #部门名称
    sortOrder int                                   #排序
);

insert into department(name, sortOrder) values('领导班子', 1);
insert into department(name, sortOrder) values('信息工程系', 2);
insert into department(name, sortOrder) values('电子工程系', 3);
insert into department(name, sortOrder) values('机电工程系', 4);
insert into department(name, sortOrder) values('汽车工程系', 5);



create table employee (
    id int not null auto_increment primary key,     #主键
    name varchar(100),                              #名称
    departmentId int not null references department(id),
    address varchar(100),
    mobile varchar(11),
    birthday date
);

insert into employee(name, departmentId, address, mobile, birthday)
values('周勇', 1, '四川成都', '13900010002', '1970-01-01');
insert into employee(name, departmentId, address, mobile, birthday)
values('敬代和', 1, '四川广元', '13900010003', '1970-01-02');
insert into employee(name, departmentId, address, mobile, birthday)
values('李武', 2, '四川广元', '13900010004', '1970-01-03');
insert into employee(name, departmentId, address, mobile, birthday)
values('云贵全', 2, '四川乐至', '18011160000', '1975-01-01');